title: CentOs创建桌面快捷方式
date: '2016-12-21 08:00:00'
updated: '2016-12-21 08:00:00'
tags: [Note]
permalink: /articles/2016/12/21/1570340350183.html
---
1. 编写快捷方式文件 vim idea.desktop

```vim
[Desktop Entry]
Name=IntelliJ IDEA 2016.3 #名称
Icon=/home/silence/idea/idea-IU-163.7743.44/bin/idea.png #图片
Exec=/home/silence/idea/idea-IU-163.7743.44/bin/idea.sh #脚本路径
Terminal=false
Type=Application
StartupNotify=true
Categories=Application:Development;Java;IDE
```
2. 复制文件到桌面