title: 2019-03-26-加入Java Geek Tech
date: '2019-03-26 08:00:00'
updated: '2019-03-26 08:00:00'
tags: [Note]
permalink: /articles/2019/03/26/1571673931451.html
---
# Java Geek Tech
一个由纯洁的微笑发起的一个团队，共同维护一个公众号Java极客技术（Javageektech）。该公众号主要用来分享 Java 开发的一些技能。
文章的作者都是微笑哥知识星球群友写的，有 Java 基础，有 Java 高级特性，从多线程，JVM 等很多方面的技术，也有一些面试经历。主要帮助群友或者其他人成长。

群友都可以投稿，但是必须写满六篇才能加入的运营团队，目前自己投稿了一篇，还要继续努力。

[Java Geek Tech](http://www.justdojava.com/)

#### One more thing
- Personal Medium Home Page: [https://medium.com/@zhuxiang134](https://medium.com/@zhuxiang134)
- Personal Website: [https://zxsilence.cn/](https://zxsilence.cn/)