title: 我在 GitHub 上的开源项目
date: '2019-10-06 13:10:35'
updated: '2019-10-06 13:10:35'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo](https://github.com/zhuSilence/solo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhuSilence/solo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/solo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhuSilence/solo/network/members "分叉数")</span>

personal website, clone from b3log/solo



---

### 2. [zhuSilence.github.io](https://github.com/zhuSilence/zhuSilence.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhuSilence/zhuSilence.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/zhuSilence.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhuSilence/zhuSilence.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://zxsilence.cn/`](https://zxsilence.cn/ "项目主页")</span>

独立域名，欢迎点击广告



---

### 3. [ARTS](https://github.com/zhuSilence/ARTS) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhuSilence/ARTS/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/ARTS/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhuSilence/ARTS/network/members "分叉数")</span>





---

### 4. [silence-study](https://github.com/zhuSilence/silence-study) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhuSilence/silence-study/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/silence-study/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhuSilence/silence-study/network/members "分叉数")</span>





---

### 5. [test](https://github.com/zhuSilence/test) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhuSilence/test/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/test/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhuSilence/test/network/members "分叉数")</span>





---

### 6. [ssm01](https://github.com/zhuSilence/ssm01) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/zhuSilence/ssm01/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/ssm01/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/zhuSilence/ssm01/network/members "分叉数")</span>

第一个ssm配置项目



---

### 7. [wechat](https://github.com/zhuSilence/wechat) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhuSilence/wechat/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhuSilence/wechat/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhuSilence/wechat/network/members "分叉数")</span>



