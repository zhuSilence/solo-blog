title: 个人博客Google AdSense接入
date: '2018-09-15 08:00:00'
updated: '2019-10-06 14:09:56'
tags: [blog]
permalink: /articles/2018/09/15/1570340343350.html
---
### 个人博客Google AdSense接入
@(公众号)[blog]
### 前言
最近将个人博客接入的Google AdSense 系统(发现了一个发家致富的方法，虽然没什么访问量~~😜)。
### Google AdSense
- 百度百科
![Alt text](https://zxsilence.cn/images/posts/articles/2018-09-15/1.png)
- 简单来说就是网站上接入广告，用户在浏览的时候如果点击了广告就会有收益。当然接入的广告是有后台可以用网站长自己控制的。

### 效果
#### 网站效果
![Alt text](https://zxsilence.cn/images/posts/articles/2018-09-15/2.png)

![Alt text](https://zxsilence.cn/images/posts/articles/2018-09-15/3.png)

#### Google AdSense后台效果~美刀。。。

![Alt text](https://zxsilence.cn/images/posts/articles/2018-09-15/4.png)

### 接入流程——简单方便
1. 首先当然有个个人网站；
2. 注册Google AdSense账号，填入相关信息，坐等审核通过，一般一两天，会有邮件通知；
3. 在网站中加入相关JS脚本代码，这段代码注册完了AdSense会提供；
4. 基本完成。。后面就是在后台配置一些自己觉得可以的广告，或者屏蔽一些不好的广告即可，以及控制一些广告类型，比如图文，链接啥的。
5. 后台效果
![Alt text](https://zxsilence.cn/images/posts/articles/2018-09-15/5.png)

### 结语
嗯，现在自己有了一个日常任务，就是每天看几次博客，然后点点广告😂，毕竟没什么访问量，还得靠自己😅
欢迎去点广告🙃🙃🙃[https://zxsilence.cn/](https://zxsilence.cn/)

#### One more thing
- Personal Medium Home Page: [https://medium.com/@zhuxiang134](https://medium.com/@zhuxiang134)
- Personal Website: [https://zxsilence.cn/](https://zxsilence.cn/)
